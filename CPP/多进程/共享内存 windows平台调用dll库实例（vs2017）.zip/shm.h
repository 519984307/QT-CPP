﻿#ifndef SHM_H
#define SHM_H

/*
Copyright(c) 2022  muyan
Company: vless

Version 2.0.0: 20221207
1. same class name for both in windows and linux.
2. add a namespace of vless_shm
3. no any various value which has no relation of you project in SM struct 

Version 1.0.2:   20221027
1.set image_count [0,255]

Version 1.0.1:  2 0221017
1. make linux use is same as windows,
share memory saved in struct and init shm with template method: e.g. shm<SM_CAM> *pshm=new shm<SM_CAM>(123);

Version 0-n:
no remember!! hahaha....


*/

#ifdef _WIN32
#include <windows.h>
#include <iostream>
#elif __linux__
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/shm.h>
#endif

#include <string>
#include <chrono>


namespace vless_shm
{
	template<typename T>
	class shm
	{
	public:	
#ifdef _WIN32
		shm(std::string _shm_addr_name, std::string proccess_name = "");// windows platform. [in]_shm_addr_name：sharememory name string, [in]proccess_name: for log.
#elif __linux__
		shm(int _shm_key_name, std::string proccess_name = ""); //linux platform. [in]_shm_key_name：sharememory name key,[in]proccess_name: for log.
#endif
		bool m_IsBuildShareMemoryOK = false;//whether to build shm ok

		bool writeMemory(T *data);//write data 
		bool readMemory(T *data, int time_ms = 0);//read data
		bool readMemory_count(T *data, int &count, int time_ms = 0); //read data with count

		~shm();
	private:
		/*sharememory*/
		void *share_memory_ptr;//ptr of share memory
		void *getMemoryPtr();//get ptr of share memory
		bool _readMemory(T *data);//read data

#ifdef _WIN32
		HANDLE hFileMap_Handle;//handle of build
		LPCWSTR lpName;//_shm_addr_name needed when building 
		LPCWSTR string2LPCWTR(std::string str);
		std::string shm_addr_name;

#elif __linux__
		int shmid;  //shm ID
		int shm_key_name = 0;//sharememory name key,
#endif
		int share_size;//size of share memory 
		int pre_count = -1;//pre data count
		int cur_count = -1;//cur data count
		int image_count = -1;//count

		char *pWritten = nullptr;
		char *pNum = nullptr;

		long long int start_time, end_time;
		time_t getTimeStamp();

	};

}
#endif // SHM_H
