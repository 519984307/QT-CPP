#ifndef _SHAREMEMORY_H
#define _SHAREMEMORY_H
#include <string.h>

#define IMAGE_SIZE 3000000
#define STR_LOG 100

struct SM_CamImage
{
        unsigned char IR_IMG[IMAGE_SIZE];
        unsigned char DEPTH_IMG[IMAGE_SIZE];
        bool m_IsIR = false;
        bool m_IsDepth = false;

	int ir_cols = 0;
	int ir_rows = 0;
        int ir_chennels = 0;

	int dep_cols = 0;
	int dep_rows = 0;
        int dep_chennels = 0;

        float value = 0;
        bool m_control = false;

        time_t m_TimeStamp = 0;

        bool m_StartDeal = false;

};

struct LOG_Result
{
	float mfloat_result;
	int mint_result;
	bool mbool_result;
	unsigned char mstr_result[STR_LOG] ;
};


#endif //_SHAREMEMORY_H


