﻿#include "shm.h"

namespace vless_shm
{

#ifdef _WIN32
	template<typename T>
	shm<T>::shm(std::string _shm_addr_name, std::string proccess_name)
	{
		m_IsBuildShareMemoryOK = false;
		lpName = string2LPCWTR(_shm_addr_name);
		shm_addr_name = _shm_addr_name;
		share_size = sizeof(T) + 2;
		//1.打开共享的文件对象
		hFileMap_Handle = OpenFileMapping(FILE_MAP_ALL_ACCESS, NULL, lpName);
		//2.判断句柄是否存在
		if (hFileMap_Handle <= 0)
		{
			//1.创建共享内存
			hFileMap_Handle = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_EXECUTE_READWRITE, 0, share_size, lpName);
			if (hFileMap_Handle)
			{
				share_memory_ptr = MapViewOfFile(hFileMap_Handle, FILE_MAP_ALL_ACCESS, 0, 0, 0);
				if (share_memory_ptr)
				{
					m_IsBuildShareMemoryOK = true;
				}
			}
		}
		else
		{
			share_memory_ptr = MapViewOfFile(hFileMap_Handle, FILE_MAP_ALL_ACCESS, 0, 0, 0);
			if (share_memory_ptr)
			{
				m_IsBuildShareMemoryOK = true;
			}
		}


		if (m_IsBuildShareMemoryOK)
		{
			std::cout << "[ " << proccess_name << " ]: build share memory ok; memory name string:" + _shm_addr_name << std::endl;
			//qDebug() << "build share memory ok";
			pWritten = (char*)share_memory_ptr + share_size - 2;
			pNum = (char*)share_memory_ptr + share_size - 1;
		}
		else
		{
			std::cout << "[ " << proccess_name << " ]: build share memory failed" << std::endl;
			//qDebug() << "build share memory failed";
		}

		//#elif __linux__
		//    printf("/**********************************/ \n    Crital Error: line: %d: This init function should be run on windows platform, "
		//           "but now is used on linux platform wrong.  \n/**********************************/ \n",__LINE__);
		//

	}
#endif

#ifdef __linux__
	template<typename  T>
	shm<T>::shm(int _shm_key_name, std::string proccess_name)
	{
		shm_key_name = _shm_key_name;
		share_size = sizeof(T) + 2;
		m_IsBuildShareMemoryOK = false;
		//Create shared memory
		shmid = shmget((key_t)shm_key_name, share_size, 0666 | IPC_CREAT);
		if (shmid == -1)
		{
			fprintf(stderr, "[%s]:shmget failed, shm name [%d]\n", proccess_name.c_str(), shm_key_name);
			return;
		}

		//Connect shared memory to the address space of the current process
		share_memory_ptr = shmat(shmid, (void*)0, 0);
		if (share_memory_ptr == (void*)-1)
		{
			printf("[%s]:Build share memory faield, shm name [%d] \n", proccess_name.c_str(), shm_key_name);
			return;
		}

		m_IsBuildShareMemoryOK = true;
		pWritten = (char*)share_memory_ptr + share_size - 2;
		pNum = (char*)share_memory_ptr + share_size - 1;
		printf("[%s]:Build share memory OK, shm name [%d] \n", proccess_name.c_str(), shm_key_name);

		//#elif _WIN32
		//    printf("/**********************************/ \n    Crital Error: line: %d: This init function should be run on linux platform, "
		//           "but now is used on winidows platform wrong.  \n/**********************************/ \n",__LINE__);
		//
	}
#endif


	template<typename  T>
	bool shm<T>::writeMemory(T *data)
	{
		if (data == nullptr)
		{
			printf("data in Nullptr, chek your input parameter;");
			return false;
		}
		//1，改变标识符
		//((T*)share_memory_ptr)->m_Written = false;//内存中的m_Written一定要设置false, 否则会在写内存的过程中读，使读数据出问题
		*pWritten = 0;
		//data->m_Written = false;//一定要设置false。否则，会在第3步写内存的过程中该标志符先写入内存，而数据未写入完成，这时读数据就会出问题；

		//2，增加计数
		//image_count = (((T*)share_memory_ptr)->image_count) + 1;//更新
		*pNum = *pNum + 1;//+1
		image_count = *pNum;
		if (image_count > 255)
		{
			image_count = 0;
		}
		//     printf("write:%d \n",image_count);
		//3.写信息
		//data->image_count=image_count;
		memcpy(share_memory_ptr, data, sizeof(T));

		//std::cout << "index:" << ((T*)share_memory_ptr)->image_count<< std::endl;

		//4.更新标识符
		//((T*)share_memory_ptr)->m_Written = true;
		*pWritten = 1;

		return true;
	}

	template<typename  T>
	bool shm<T>::readMemory(T *data, int time_ms)
	{
		//1、先获取一次数据
		double cost_time = 0;
		start_time = getTimeStamp();
		if (_readMemory(data))
		{
			//printf("bool shm_linux::getMemory_pre(SM_Cam *data,int ms_time): first ok.\n");
			return true;
		}
		else
		{
			end_time = getTimeStamp();
			cost_time = end_time - start_time;
			if (cost_time > time_ms)
				return false;
		}
		//2、第一次没有获取到，接下来连续读取，并和设定时间进行比较判断。
		while (true)
		{
			if (_readMemory(data))
				return true;
			else
			{
				end_time = getTimeStamp();
				cost_time = end_time - start_time;
				//3、最后一次还是没有获取到，则返回false
				if (cost_time > time_ms)
					return false;
			}
		}

		return false;
	}

	template<typename T>
	bool shm<T>::readMemory_count(T *data, int &count, int time_ms /*= 0*/)
	{
		//1、先获取一次数据
		double cost_time = 0;
		start_time = getTimeStamp();
		if (_readMemory(data))
		{
			//printf("bool shm_linux::getMemory_pre(SM_Cam *data,int ms_time): first ok.\n");
			count = (unsigned char)*pNum;
			return true;
		}
		else
		{
			end_time = getTimeStamp();
			cost_time = end_time - start_time;
			if (cost_time > time_ms)
				return false;
		}
		//2、第一次没有获取到，接下来连续读取，并和设定时间进行比较判断。
		while (true)
		{
			if (_readMemory(data))
			{
				count = (unsigned char)*pNum;
				return true;
			}
			else
			{
				end_time = getTimeStamp();
				cost_time = end_time - start_time;
				//3、最后一次还是没有获取到，则返回false
				if (cost_time > time_ms)
					return false;
			}
		}

		return false;
	}



	template<typename  T>
	shm<T>::~shm()
	{
#ifdef _WIN32
		//解除映射
		UnmapViewOfFile(share_memory_ptr);
		//关闭句柄
		CloseHandle(hFileMap_Handle);
		printf("Release shm successfully. shm addr:[%s] \n", shm_addr_name.c_str());

#elif __linux__
		if (shmdt(share_memory_ptr) == -1)
		{
			fprintf(stderr, "shmdt failed.\n");
			return;
		}
		if (shmctl(shmid, IPC_RMID, 0) == -1)
		{
			fprintf(stderr, "shmctl(IPC_RMID) failed.\n");
			return;
		}
		printf("Release shm successfully. shm name: [%d] \n", shm_key_name);
#endif

	}

	template<typename  T>
	void *shm<T>::getMemoryPtr()
	{
		return share_memory_ptr;
	}

	template<typename  T>
	bool shm<T>::_readMemory(T *data)
	{
		if (data == nullptr)
		{
			printf("data in Nullptr, chek your input parameter;");
			return false;
		}
		//1.获取计数
		//cur_count = ((T*)share_memory_ptr)->image_count;
		cur_count = *pNum;
		//2.判断计数
		if (pre_count != cur_count)
		{
			//if (((T*)share_memory_ptr)->m_Written)
			if (*pWritten)
			{
				//3.获取共享内存信息
				memcpy(data, share_memory_ptr, sizeof(T));
				//4.返回true
				//if (((T*)share_memory_ptr)->m_Written && (((T*)share_memory_ptr)->image_count == cur_count))//same count image
				int m_w = *pWritten;
				int m_n = *pNum;
				if (m_w && (m_n == cur_count))//same count image
				{
					pre_count = cur_count;
					//std::cout << "index:" << cur_count<<" , ";
					return true;
				}
			}
		}
		return false;
	}


#ifdef _WIN32
	template<typename  T>
	LPCWSTR shm<T>::string2LPCWTR(std::string str)
	{
		size_t size = str.length();
		wchar_t * buffer = new wchar_t[size + 1];
		MultiByteToWideChar(CP_ACP, 0, str.c_str(), size, buffer, size * sizeof(wchar_t));
		buffer[size] = 0;
		return buffer;
	}
#endif

	template<typename  T>
	time_t shm<T>::getTimeStamp()
	{
		std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> tp = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
		auto tmp = std::chrono::duration_cast<std::chrono::milliseconds>(tp.time_since_epoch());
		time_t timestamp = tmp.count();
		//std::time_t timestamp = std::chrono::system_clock::to_time_t(tp);
		return timestamp;
	}
}